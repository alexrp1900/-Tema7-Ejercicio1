package T8_Ej1;

public class main_T8_E1 {

	public static void main(String[] args) {

		Empleado e1 = new Empleado("Rober", "64713134A", 34, true, 1500);
		Programador p1 = new Programador(250,"Java");
		
		System.out.println(e1.getNombre()+" "+e1.getDNI()+" "+e1.getEdad()+" "+e1.isCasado()+" "+e1.getSalario());
		System.out.println(p1.getLineasCodigoPorHora()+" "+p1.getLenguajeDominante());
	}

}
