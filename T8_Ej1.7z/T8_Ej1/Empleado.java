package T8_Ej1;

public class Empleado {

	private String nombre;
	private String DNI;
	private int edad;
	private boolean casado;
	private double salario;

	public Empleado() {

	}

	public Empleado(String nombre, String DNI, int edad, boolean casado, double salario) {
		this.nombre = nombre;
		this.DNI = DNI;
		this.edad = edad;
		this.casado = casado;
		this.salario = salario;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getDNI() {
		return DNI;
	}

	public void setDNI(String dNI) {
		DNI = dNI;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	public boolean isCasado() {
		return casado;
	}

	public void setCasado(boolean casado) {
		this.casado = casado;
	}

	public double getSalario() {
		return salario;
	}

	public void setSalario(double salario) {
		this.salario = salario;
	}

	public String clasificacion() {

		String resultado = "";

		if (this.edad < 18) {
			resultado = "Novato";
		}
		if (this.edad >= 19 && this.edad <= 25) {
			resultado = "Junior";
		}
		if (this.edad > 25) {
			resultado = "Senior";
		}
		return resultado;
	}

	public void MostrarDatos(String nombre, String DNI, int edad, boolean casado, double salario) {

	}

	public void aumentarSueldo(int porcentaje) {

		this.salario = this.salario * porcentaje;
	}

	public void mostrarMensaje(String resutlado) {

	}

}
