package T8_Ej1;

public class Programador {

	private int lineasCodigoPorHora;
	private String lenguajeDominante;

	public Programador() {

	}

	public Programador(int lineasCodigoPorHora, String lenguajeDominante) {
		this.lineasCodigoPorHora = lineasCodigoPorHora;
		this.lenguajeDominante = lenguajeDominante;
	}

	public int getLineasCodigoPorHora() {
		return lineasCodigoPorHora;
	}

	public void setLineasCodigoPorHora(int lineasCodigoPorHora) {
		this.lineasCodigoPorHora = lineasCodigoPorHora;
	}

	public String getLenguajeDominante() {
		return lenguajeDominante;
	}

	public void setLenguajeDominante(String lenguajeDominante) {
		this.lenguajeDominante = lenguajeDominante;
	}

	public String nivelProgramacion() {

		String resultado = "";

		if (this.lineasCodigoPorHora < 200) {
			resultado = "Level 1";
		}
		
		if (this.lineasCodigoPorHora >= 200 && this.lineasCodigoPorHora <= 500) {
			resultado = "Level 2";
		}
		
		if (this.lineasCodigoPorHora > 500) {
			resultado = "Level 3";
		}
		
		return resultado;
	}
}
